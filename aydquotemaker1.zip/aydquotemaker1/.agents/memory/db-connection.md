---
name: DB connection
description: How the database pool is configured and which database is actually in use
---

The app uses Replit's built-in PostgreSQL (not the external Neon.tech instance).

**How:** `server/config/neondb.ts` now prefers `DATABASE_URL` (Replit PostgreSQL) over the `NEON_*` individual env vars. `NEON_DATABASE_PASSWORD` is not set in secrets, so the old NEON-only pool config always failed silently.

**Why:** `NEON_HOST`/`NEON_DATABASE`/`NEON_USER` are set in Replit secrets, but `NEON_DATABASE_PASSWORD` was never added — the pool fell back to unauthorized connections. `DATABASE_URL` (Replit PostgreSQL) IS set and working.

**How to apply:** If someone adds `NEON_DATABASE_PASSWORD` in the future, the pool will auto-switch to the Neon host. Schema was applied to Replit PostgreSQL via `executeSql` (see `server/config/neon-schema.sql` for the canonical schema, which also includes `password_hash`, `reset_token`, `reset_token_expires` on the `users` table).
